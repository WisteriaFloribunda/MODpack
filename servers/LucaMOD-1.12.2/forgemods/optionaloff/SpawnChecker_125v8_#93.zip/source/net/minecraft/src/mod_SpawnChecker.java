package net.minecraft.src;

import static spawnchecker.enums.Mode.Option.*;

import java.util.Map;
import java.util.logging.Level;

import net.minecraft.client.Minecraft;
import spawnchecker.SpawnChecker;

/**
 * mod_SpawnChecker.
 *
 * @author fillppo (substitute version author takuru/ale)
 * @version {@value #VERSION}
 */
public class mod_SpawnChecker extends BaseModEx
{
    private static final String VERSION = "125v8 #93";

    /**
     * mode.
     */
    @MLProp(name = "mode", info = "sc: Spawable point checker, sf: Slime chunk finder, sv: Spawner visualizer")
    public static String modeValue = "sc";

    /**
     * Spawn-able point checker submode.
     */
    @MLProp(name = "option_sc", min = 0, max = 31, info = "Spawnable point checker option. bit flag [0:disable, 1:+marker, 2:+guideline, 4:+force mode, 8:+slime finder, 16:+ghast finder")
    public static int optionSC = 0;
    @MLProp(name = "option_set_sc", info = "sc mode option set.")
    public static String optionSetSC;

    /**
     * Slime chunk finder submode.
     */
    @MLProp(name = "option_sf", min = 0, max = 7, info = "Slime chunk finder option. bit flag [0:disable, 1:+marker, 2:+guideline, 4:+chunk marker")
    public static int optionSF = 0;
    @MLProp(name = "option_set_sf", info = "sf mode option set.")
    public static String optionSetSF;

    /**
     * Spawner visualizer submode.
     */
    @MLProp(name = "option_sv", min = 0, max = 63, info = "Spawner visualizer option. bit flag [0:disable, 1:+spawner, 2:+spawn area, 4:+spawnable point, 8:+unspawnable point, 16:+duplication limit area, 32:+activate area")
    public static int optionSV = 1;
    @MLProp(name = "option_set_sv", info = "sv mode option set.")
    public static String optionSetSV;

    /**
     * �����`�F�b�N�͈�.
     */
    @MLProp(name = "horizontal_range", min = 1, max = 32, info = "horizontal check area range.")
    public static int rangeHorizontal = 10;

    /**
     * �����`�F�b�N�͈�.
     */
    @MLProp(name = "vertical_range", min = 1, max = 32, info = "vertical check area range.")
    public static int rangeVertical = 5;

    /**
     * �}�[�J�[�̖��邳.
     */
    @MLProp(name = "brightness", min = -5, max = 5, info = "marker and guidline default brightness.")
    public static int brightness = 0;

    /**
     * �J���}��؂�̃A�C�e��ID������.
     */
    @MLProp(name = "enabling_item_ids", info = "comma-separated item id. ex: enabling_item_ids=50,89,91 (default: 50 = torch's ID)")
    public static String enablingItemsCSV = String.valueOf(Block.torchWood.blockID);

    /**
     * �`�F�b�N�Ԋu�̍ŏ�����.
     */
    @MLProp(name = "checking_duration", min = 1, max = 10000, info = "milliseconds checking minimum duration.")
    public static int checkMinDuration = 300;

    /**
     * ��񃁃b�Z�[�W�̕\������.
     */
    @MLProp(name = "information_timeout", min = 1, max = 10000, info = "milliseconds information message timeout.")
    public static int informationTimeout = 2500;

    /**
     * �X�|�[�i�[�������[�h���̉E�N���b�N�L�������؂�ւ�.
     */
    @MLProp(name = "enabled_spawner_visualizer_right_click", info = "when this value change to false, disabled 'right click (item use) key' for spawner visualizer toggle visibility.")
    public static boolean enabledSpawnerVisualizerRightClick = true;

    /*
     * ����3mob�}�[�J�[�F.
     */
    @MLProp(name = "spawn_marker1_color_R", min = 0, max = 255, info = "enderman marker color.(default: #40ff00)")
    public static short marker1Red = 64;
    @MLProp(name = "spawn_marker1_color_G", min = 0, max = 255, info = "enderman marker color.")
    public static short marker1Green = 255;
    @MLProp(name = "spawn_marker1_color_B", min = 0, max = 255, info = "enderman marker color.")
    public static short marker1Blue = 0;
    @MLProp(name = "spawn_marker1_color_A", min = 0, max = 255, info = "enderman marker alpha.(default: 100(39.2%))")
    public static short marker1Alpha = 100;

    /*
     * ����2mob�}�[�J�[�F.
     */
    @MLProp(name = "spawn_marker2_color_R", min = 0, max = 255, info = "height 2 mob marker color.(default: #ffff40)")
    public static short marker2Red = 255;
    @MLProp(name = "spawn_marker2_color_G", min = 0, max = 255, info = "height 2 mob marker color.")
    public static short marker2Green = 255;
    @MLProp(name = "spawn_marker2_color_B", min = 0, max = 255, info = "height 2 mob marker color.")
    public static short marker2Blue = 64;
    @MLProp(name = "spawn_marker2_color_A", min = 0, max = 255, info = "height 2 mob marker alpha.(default: 100(39.2%))")
    public static short marker2Alpha = 100;

    /*
     * �N���}�[�J�[�F.
     */
    @MLProp(name = "spawn_marker3_color_R", min = 0, max = 255, info = "spider marker color.(default: #4040ff)")
    public static short marker3Red = 64;
    @MLProp(name = "spawn_marker3_color_G", min = 0, max = 255, info = "spider marker color.")
    public static short marker3Green = 64;
    @MLProp(name = "spawn_marker3_color_B", min = 0, max = 255, info = "spider marker color.")
    public static short marker3Blue = 255;
    @MLProp(name = "spawn_marker3_color_A", min = 0, max = 255, info = "spider marker alpha.(default: 100(39.2%))")
    public static short marker3Alpha = 100;

    /*
     * �X���C���}�[�J�[�F.
     */
    @MLProp(name = "spawn_marker4_color_R", min = 0, max = 255, info = "slime marker color.(default: #50e8c9)")
    public static short marker4Red = 80;
    @MLProp(name = "spawn_marker4_color_G", min = 0, max = 255, info = "slime marker color.")
    public static short marker4Green = 232;
    @MLProp(name = "spawn_marker4_color_B", min = 0, max = 255, info = "slime marker color.")
    public static short marker4Blue = 201;
    @MLProp(name = "spawn_marker4_color_A", min = 0, max = 255, info = "slime marker alpha.(default: 100(39.2%))")
    public static short marker4Alpha = 100;

    /*
     * �K�X�g�}�[�J�[�F.
     */
    @MLProp(name = "spawn_marker5_color_R", min = 0, max = 255, info = "ghast marker color.(default: #4040ff)")
    public static short marker5Red = 255;
    @MLProp(name = "spawn_marker5_color_G", min = 0, max = 255, info = "ghast marker color.")
    public static short marker5Green = 255;
    @MLProp(name = "spawn_marker5_color_B", min = 0, max = 255, info = "ghast marker color.")
    public static short marker5Blue = 255;
    @MLProp(name = "spawn_marker5_color_A", min = 0, max = 255, info = "ghast marker alpha.(default: 100(39.2%))")
    public static short marker5Alpha = 100;

    /*
     * �X���C���`�����N�}�[�J�[�F.
     */
    @MLProp(name = "slime_chunk_color_R", min = 0, max = 255, info = "slime chunk marker color.(default: #50e8c9)")
    public static short slimeChunkRed = 80;
    @MLProp(name = "slime_chunk_color_G", min = 0, max = 255, info = "slime chunk marker color.")
    public static short slimeChunkGreen = 232;
    @MLProp(name = "slime_chunk_color_B", min = 0, max = 255, info = "slime chunk marker color.")
    public static short slimeChunkBlue = 201;
    @MLProp(name = "slime_chunk_color_A", min = 0, max = 255, info = "slime chunk marker alpha.(default: 100(39.2%))")
    public static short slimeChunkAlpha = 64;

    /*
     * �X�|�i�[�{�[�_�[�F.
     */
    @MLProp(name = "spawner_border_color_R", min = 0, max = 255, info = "spawner border color.(default: #ff0000)")
    public static short spawnerRed = 225;
    @MLProp(name = "spawner_border_color_G", min = 0, max = 255, info = "spawner border color.")
    public static short spawnerGreen = 0;
    @MLProp(name = "spawner_border_color_B", min = 0, max = 255, info = "spawner border color.")
    public static short spawnerBlue = 0;
    @MLProp(name = "spanwer_border_color_A", min = 0, max = 255, info = "spawner border alpha.(default: 255(100.0%))")
    public static short spawnerAlpha = 255;

    /*
     * ���u�X�|�[���G���A�F.
     */
    @MLProp(name = "spawner_spawn_area_color_R", min = 0, max = 255, info = "spawner spawn area color.(default: #00ff00)")
    public static short spawnerSpawnAreaRed = 0;
    @MLProp(name = "spawner_spawn_area_color_G", min = 0, max = 255, info = "spawner spawn area color.")
    public static short spawnerSpawnAreaGreen = 255;
    @MLProp(name = "spawner_spawn_area_color_B", min = 0, max = 255, info = "spawner spawn area color.")
    public static short spawnerSpawnAreaBlue = 0;
    @MLProp(name = "spawner_spawn_area_color_A", min = 0, max = 255, info = "spawner spawn area alpha.(default: 100(39.2%))")
    public static short spawnerSpawnAreaAlpha = 100;

    /*
     * ���u�N�������G���A�F.
     */
    @MLProp(name = "spawner_duplication_area_color_R", min = 0, max = 255, info = "spawner duplication area color.(default: #0000ff)")
    public static short duplicationAreaRed = 0;
    @MLProp(name = "spawner_duplication_area_color_G", min = 0, max = 255, info = "spawner duplicationarea color.")
    public static short duplicationAreaGreen = 0;
    @MLProp(name = "spawner_duplication_area_color_B", min = 0, max = 255, info = "spawner duplication area color.")
    public static short duplicationAreaBlue = 255;
    @MLProp(name = "spawner_duplication_area_color_A", min = 0, max = 255, info = "spawner duplication area alpha.(default: 100(39.2%))")
    public static short duplicationAreaAlpha = 100;

    /*
     * �X�|�i�[�̃X�|�[������|�C���g�F.
     */
    @MLProp(name = "spawner_spawnable_point_line_color_R", min = 0, max = 255, info = "spawner activate area color.(default: #ffa080)")
    public static short spawnerSpawnablePointRed = 255;
    @MLProp(name = "spawner_spawnable_point_line_color_G", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerSpawnablePointGreen = 160;
    @MLProp(name = "spawner_spawnable_point_line_color_B", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerSpawnablePointBlue = 128;
    @MLProp(name = "spawner_spawnable_point_line_color_A", min = 0, max = 255, info = "spawner activate area alpha.(default: 64(25.1%))")
    public static short spawnerSpawnablePointAlpha = 64;

    /*
     * �X�|�i�[�̃X�|�[�����Ȃ��|�C���g�F.
     */
    @MLProp(name = "spawner_unspawnable_point_line_color_R", min = 0, max = 255, info = "spawner activate area color.(default: #a0ffd6)")
    public static short spawnerUnspawnablePointRed = 160;
    @MLProp(name = "spawner_unspawnable_point_line_color_G", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerUnspawnablePointGreen = 255;
    @MLProp(name = "spawner_unspawnable_point_line_color_B", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerUnspawnablePointBlue = 214;
    @MLProp(name = "spawner_unspawnable_point_line_color_A", min = 0, max = 255, info = "spawner activate area alpha.(default: 64(25.1%))")
    public static short spawnerUnspawnablePointAlpha = 64;

    /*
     * �X�|�i�[�A�N�e�B�u�G���A�F.
     */
    @MLProp(name = "spawner_activate_area_color_R", min = 0, max = 255, info = "spawner activate area color.(default: #402010)")
    public static short spawnerActivateAreaRed = 64;
    @MLProp(name = "spawner_activate_area_color_G", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerActivateAreaGreen = 32;
    @MLProp(name = "spawner_activate_area_color_B", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerActivateAreaBlue = 16;
    @MLProp(name = "spawner_activate_area_color_A", min = 0, max = 255, info = "spawner activate area alpha.(default: 64(25.1%))")
    public static short spawnerActivateAreaAlpha = 64;

    /*
     * �X�|�i�[�A�N�e�B�u�G���A�F(��).
     */
    @MLProp(name = "spawner_activate_area_line_color_R", min = 0, max = 255, info = "spawner activate area color.(default: #ff8080)")
    public static short spawnerActivateAreaLineRed = 255;
    @MLProp(name = "spawner_activate_area_line_color_G", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerActivateAreaLineGreen = 128;
    @MLProp(name = "spawner_activate_area_line_color_B", min = 0, max = 255, info = "spawner activate area color.")
    public static short spawnerActivateAreaLineBlue = 128;
    @MLProp(name = "spawner_activate_area_line_color_A", min = 0, max = 255, info = "spawner activate area alpha.(default: 96(37.6%))")
    public static short spawnerActivateAreaLineAlpha = 96;

    /*
     * ���b�Z�[�W�`��ʒu�I�t�Z�b�g.
     */
    @MLProp(name = "info_v_offset", min = -100, max = 100, info = "information message vertical offset.")
    public static int infoVOffset = -50;
    @MLProp(name = "info_h_offset", min = -30, max = 30, info = "information message horizontal offset.")
    public static int infoHOffset = 0;

    /*
     * ���b�Z�[�W�F.
     */
    @MLProp(name = "info_color_R", min = 0, max = 255, info = "message color.(default: #ffffff)")
    public static short infoRed = 255;
    @MLProp(name = "info_color_G", min = 0, max = 255, info = "message color.")
    public static short infoGreen = 255;
    @MLProp(name = "info_color_B", min = 0, max = 255, info = "message color.")
    public static short infoBlue = 255;

    /*
     * �����_�����O�p�G���e�B�e�B�ʒu�I�t�Z�b�g.
     */
    @MLProp(name = "entity_offset_x", min = -100.0D, max = 100.0D, info = "offset for marker renderer entity position.")
    public static double entityOffsetX = 0.0D;
    @MLProp(name = "entity_offset_y", min = -100.0D, max = 100.0D, info = "offset for marker renderer entity position.")
    public static double entityOffsetY = 5.0D;
    @MLProp(name = "entity_offset_z", min = -100.0D, max = 100.0D, info = "offset for marker renderer entity position.")
    public static double entityOffsetZ = 0.0D;

    /**
     * debug mode flag.
     */
    @MLProp(name = "debug")
    public static boolean DEBUG = !RELEASE;

    static
    {
        optionSetSC = "" + DISABLE
                + "," + (GHAST)
                + "," + (GHAST | GUIDELINE)
                + "," + (MARKER)
                + "," + (MARKER | GUIDELINE)
                + "," + (GHAST | FORCE)
                + "," + (GHAST | GUIDELINE | FORCE)
                + "," + (MARKER | FORCE)
                + "," + (MARKER | GUIDELINE | FORCE)
                + "," + (MARKER | SLIME)
                + "," + (MARKER | SLIME | GUIDELINE)
                + "," + (MARKER | SLIME | FORCE)
                + "," + (MARKER | SLIME | GUIDELINE | FORCE)
                ;
        optionSetSF = "" + DISABLE
                + "," + (MARKER)
                + "," + (MARKER | GUIDELINE)
                + "," + (CHUNK_MARKER)
                + "," + (MARKER | CHUNK_MARKER)
                + "," + (MARKER | GUIDELINE | CHUNK_MARKER)
                ;
        optionSetSV = "" + (SPAWNER)
                + "," + (SPAWNER | SPAWN_AREA)
                + "," + (SPAWNER | SPAWN_AREA | SPAWNABLE_POINT | DUPLICATION_AREA)
                + "," + (SPAWNER | SPAWN_AREA | UNSPAWNABLE_POINT | DUPLICATION_AREA)
                + "," + (SPAWNER | SPAWN_AREA | SPAWNABLE_POINT | UNSPAWNABLE_POINT | DUPLICATION_AREA)
                + "," + (SPAWNER | ACTIVATE_AREA)
                + "," + (SPAWNER | SPAWN_AREA | ACTIVATE_AREA)
                + "," + (SPAWNER | SPAWN_AREA | SPAWNABLE_POINT | DUPLICATION_AREA | ACTIVATE_AREA)
                + "," + (SPAWNER | SPAWN_AREA | UNSPAWNABLE_POINT | DUPLICATION_AREA | ACTIVATE_AREA)
                + "," + (SPAWNER | SPAWN_AREA | SPAWNABLE_POINT | UNSPAWNABLE_POINT | DUPLICATION_AREA | ACTIVATE_AREA)
                ;
    }

    private final SpawnChecker checker;

    /**
     * Constructor.
     */
    public mod_SpawnChecker()
    {
        super();
        loadConfig();
        String trace = properties.getProperty("trace");

        if (trace != null && trace.equals("true"))
        {
            logger.setLevel(Level.ALL);
        }
        else
        {
            logger.setLevel(DEBUG ? Level.FINEST : Level.FINER);
        }

        checker = new SpawnChecker(this);
        // traceEnabled = true; // �J������p �g���[�X���O�o�̓t���O
    }

    @Override
    public String getVersion()
    {
        return VERSION;
    }

    @Override
    public void load()
    {
        checker.initialize();
    }

    @Override
    public boolean onTickInGame(float renderPartialTicks, Minecraft game)
    {
        return checker.onTick(game);
    }

    @Override
    public void keyboardEvent(KeyBinding key)
    {
        checker.handleKeyboardEvent(key);
    }

    @Override
    public void addRenderer(Map entityRenderMap)
    {
        checker.addRender(entityRenderMap);
    }
}