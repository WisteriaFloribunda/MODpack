package spawnchecker.constants;

import static net.minecraft.src.BaseModEx.RELEASE;

/**
 * reflections constants.
 *
 * @author takuru/ale
 */
public final class ReflectionConstants
{
    // for minecraft1.2.5 (MCP6.2)
    /**
     * sendQueue.
     *
     * @see net.minecraft.src.WorldClient
     * */
    public static final String SEND_QUEUE = RELEASE ? "H" : "sendQueue";

    /**
     * netManager.
     *
     * @see net.minecraft.src.NetClientHandler
     */
    public static final String NET_MANAGER = RELEASE ? "g" : "netManager";

    /**
     * remoteSocketAddress.
     *
     * @see net.minecraft.src.NetworkManager
     */
    public static final String REMOTE_ADDR = RELEASE ? "i" : "remoteSocketAddress";

    private ReflectionConstants()
    {
    }
}
