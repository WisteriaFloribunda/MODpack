package spawnchecker;

import static spawnchecker.constants.Constants.*;
import static spawnchecker.enums.Mode.Option.*;

import java.awt.Color;

import net.minecraft.src.Entity;
import net.minecraft.src.OpenGlHelper;
import net.minecraft.src.Profiler;
import net.minecraft.src.Render;
import net.minecraft.src.RenderHelper;
import net.minecraft.src.Tessellator;
import net.minecraft.src.mod_SpawnChecker;

import org.lwjgl.opengl.GL11;
import org.lwjgl.util.glu.GLU;
import org.lwjgl.util.glu.Sphere;

import spawnchecker.enums.Mode;
import spawnchecker.enums.Mode.Option;
import spawnchecker.enums.SpawnableEntity;
import spawnchecker.markers.ChunkMarker;
import spawnchecker.markers.MarkerBase;
import spawnchecker.markers.SpawnPointMarker;
import spawnchecker.markers.SpawnerMarker;
import spawnchecker.utils.EnablingItemsHelper;

/**
 * SpawnChecker render class.
 *
 * @author takuru/ale
 */
class RenderSpawnChecker extends Render
{
    Sphere sphere = new Sphere();
    private float currentTick;

    public void drawSpawnChecker(EntitySpawnChecker entity, double x, double y, double z, float partialTickTime)
    {
        Settings settings = SpawnChecker.getSettings();
        Mode mode = settings.getCurrentMode();

        if (mode.getOption() == DISABLE)
        {
            return;
        }

        currentTick = entity.tickCount + partialTickTime;
        int brightness = BASE_BRIGHTNESS + settings.getBrightness() * BRIGHTNESS_RATIO;
        boolean marker = mode.hasOption(Option.MARKER);
        boolean guideline = mode.hasOption(Option.GUIDELINE);
        GL11.glPushMatrix();
        GL11.glDisable(GL11.GL_TEXTURE_2D);
        GL11.glDisable(GL11.GL_LIGHTING);
        GL11.glEnable(GL11.GL_BLEND);
        GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
        OpenGlHelper.setLightmapTextureCoords(OpenGlHelper.lightmapTexUnit, (float) 240.0f, (float) 240.0f);
        RenderHelper.disableStandardItemLighting();

        switch (mode)
        {
            case SPAWABLE_POINT_CHECKER:
                renderSpawnablePoint(mode, marker, guideline, brightness);
                break;

            case SLIME_CHUNK_FINDER:
                renderSlimeChunkFinder(mode, marker, guideline, brightness);
                break;

            case SPAWNER_VISUALIZER:
                renderSpawnerVisualizer(mode, brightness);
                break;
        }

        RenderHelper.enableStandardItemLighting();
        GL11.glDisable(GL11.GL_BLEND);
        GL11.glEnable(GL11.GL_TEXTURE_2D);
        GL11.glEnable(GL11.GL_LIGHTING);
        GL11.glPopMatrix();
    }

    private void renderSpawnablePoint(Mode mode, boolean marker, boolean guideline, int brightness)
    {
        if (!mode.hasOption(Mode.Option.FORCE) && !EnablingItemsHelper.hasEnablingItem())
        {
            return;
        }

        boolean ghast = mode.hasOption(Option.GHAST);
        Settings settings = SpawnChecker.getSettings();

        for (SpawnPointMarker spm : settings.getRenderDataForSpawnPointList())
        {
            boolean isGhast = spm.spawnableEntity.equals(SpawnableEntity.GHAST);
            boolean drawingMarker = marker || (isGhast && ghast);
            boolean drawingGuideline;
            drawingGuideline = ghast ? isGhast && guideline : guideline;
            Color color = settings.getColorByMob(spm.spawnableEntity);
            drawSpawnCheckMarker(spm, color, brightness, drawingMarker, drawingGuideline);
        }
    }

    private void renderSlimeChunkFinder(Mode mode, boolean marker, boolean guideline, int brightness)
    {
        Settings settings = SpawnChecker.getSettings();
        Color slimeChunkColor = settings.getColorSlimeChunk();

        for (MarkerBase<?> m : settings.getRenderDataForChunkMarkerList())
        {
            if (m instanceof SpawnPointMarker)
            {
                SpawnPointMarker spm = (SpawnPointMarker) m;
                Color color = settings.getColorByMob(spm.spawnableEntity);
                drawSpawnCheckMarker(spm, color, brightness, marker, guideline);
                continue;
            }

            if (m instanceof ChunkMarker && mode.hasOption(CHUNK_MARKER))
            {
                ChunkMarker cm = (ChunkMarker) m;
                double minX = cm.minX - renderManager.field_1222_l;
                double minY = Math.max(cm.minY, WORLD_HEIGHT_MIN) - renderManager.field_1221_m;
                double minZ = cm.minZ - renderManager.field_1220_n;
                double maxX = cm.maxX - renderManager.field_1222_l;
                double maxY = Math.min(cm.maxY, WORLD_HEIGHT_MAX) - renderManager.field_1221_m;
                double maxZ = cm.maxZ - renderManager.field_1220_n;
                drawAreaSquares(minX, minY, minZ, maxX, maxY, maxZ,
                        SLIME_CHUNK_MERKER_INTERVAL, slimeChunkColor, brightness);
                continue;
            }
        }
    }

    private void renderSpawnerVisualizer(Mode mode, int brightness)
    {
        Settings settings = SpawnChecker.getSettings();
        SpawnerMarker marker = settings.getRenderDataForSpawnerMarker();

        if (marker == null || !marker.visible)
        {
            return;
        }

        if (mode.hasOption(SPAWNER))
        {
            double minX = marker.centerMinX - renderManager.field_1222_l;
            double minY = marker.centerMinY - renderManager.field_1221_m;
            double minZ = marker.centerMinZ - renderManager.field_1220_n;
            double maxX = marker.centerMaxX - renderManager.field_1222_l;
            double maxY = marker.centerMaxY - renderManager.field_1221_m;
            double maxZ = marker.centerMaxZ - renderManager.field_1220_n;
            drawBoxBorder(minX, minY, minZ, maxX, maxY, maxZ, settings.getColorSpawnerBorder(), brightness);
        }

        if (mode.hasOption(SPAWN_AREA))
        {
            double minX = marker.areaMinX - renderManager.field_1222_l + SPAWNAREA_AREA_OFFSET;
            double minY = marker.areaMinY - renderManager.field_1221_m;
            double minZ = marker.areaMinZ - renderManager.field_1220_n + SPAWNAREA_AREA_OFFSET;
            double maxX = marker.areaMaxX - renderManager.field_1222_l - SPAWNAREA_AREA_OFFSET;
            double maxY = marker.areaMaxY - renderManager.field_1221_m;
            double maxZ = marker.areaMaxZ - renderManager.field_1220_n - SPAWNAREA_AREA_OFFSET;
            Color areaColor = settings.getColorSpawnerSpawnArea();
            drawBoxBorder(minX, minY + SPAWNAREA_AREA_OFFSET, minZ,
                    maxX, maxY - SPAWNAREA_AREA_OFFSET, maxZ, areaColor, brightness);
            minX -= SPAWNAREA_AREA_OFFSET + SPAWNAREA_AREA_OFFSET;
            minY -= SPAWNAREA_AREA_OFFSET + SPAWNAREA_AREA_OFFSET;
            minZ -= SPAWNAREA_AREA_OFFSET + SPAWNAREA_AREA_OFFSET;
            maxX += SPAWNAREA_AREA_OFFSET + SPAWNAREA_AREA_OFFSET;
            maxY += SPAWNAREA_AREA_OFFSET + SPAWNAREA_AREA_OFFSET;
            maxZ += SPAWNAREA_AREA_OFFSET + SPAWNAREA_AREA_OFFSET;
            drawBoxBorder(minX, minY - SPAWNAREA_AREA_OFFSET, minZ,
                    maxX, maxY + SPAWNAREA_AREA_OFFSET, maxZ, areaColor, brightness);
        }

        if (mode.hasOption(SPAWNABLE_POINT | UNSPAWNABLE_POINT))
        {
            float rotateAngle = currentTick * SPAWNER_POINT_MARKER_TICK_RATIO;
            boolean isDrawSpawnablePoint = mode.hasOption(SPAWNABLE_POINT);
            boolean isDrawUnspawnablePoint = mode.hasOption(UNSPAWNABLE_POINT);
            Color colorSpawnable = settings.getColorSpawnerSpawnablePoint();
            Color colorUnspawnable = settings.getColorSpawnerUnspawnablePoint();
            int index = 0;
            int maxX = marker.x + 4;
            int maxY = marker.y + 2;
            int maxZ = marker.z + 4;

            for (int ix = marker.x - 4; ix < maxX; ix++)
            {
                for (int iz = marker.z - 4; iz < maxZ; iz++)
                {
                    for (int iy = marker.y - 1; iy < maxY; iy++)
                    {
                        float a = (float)(currentTick + marker.spawnablesOffset[index]) * 0.06f;
                        float yOffset = (float) Math.sin(a) * 0.02f;
                        // �����ɂ��邽�ߊe���W+0.5d
                        double x = (double) ix - renderManager.field_1222_l + 0.5d;
                        double y = (double) iy - renderManager.field_1221_m + 0.5d + yOffset;
                        double z = (double) iz - renderManager.field_1220_n + 0.5d;

                        if (marker.spawnables[index++])
                        {
                            if (isDrawSpawnablePoint)
                            {
                                drawSpawnablePointSphere(x, y, z, rotateAngle, colorSpawnable, brightness);
                            }
                        }
                        else
                        {
                            if (isDrawUnspawnablePoint)
                            {
                                drawSpawnablePointSphere(x, y, z, rotateAngle, colorUnspawnable, brightness);
                            }
                        }
                    }
                }
            }
        }

        if (mode.hasOption(DUPLICATION_AREA))
        {
            double minX = marker.duplicationAreaMinX - renderManager.field_1222_l;
            double minY = marker.duplicationAreaMinY - renderManager.field_1221_m;
            double minZ = marker.duplicationAreaMinZ - renderManager.field_1220_n;
            double maxX = marker.duplicationAreaMaxX - renderManager.field_1222_l;
            double maxY = marker.duplicationAreaMaxY - renderManager.field_1221_m;
            double maxZ = marker.duplicationAreaMaxZ - renderManager.field_1220_n;
            Color areaColor = settings.getColorSpawnerDuplicationArea();
            drawBoxBorder(minX, minY, minZ, maxX, maxY, maxZ, areaColor, brightness);
            drawAreaSquares(minX, minY + SPAWNAREA_AREA_INTERVAL / 2d, minZ, maxX, maxY, maxZ,
                    SPAWNAREA_AREA_INTERVAL, areaColor, brightness);
        }

        if (mode.hasOption(ACTIVATE_AREA))
        {
            double centerX = (double) marker.x + 0.5d - renderManager.field_1222_l;
            double centerY = (double) marker.y + 0.5d - renderManager.field_1221_m;
            double centerZ = (double) marker.z + 0.5d - renderManager.field_1220_n;
            drawActivateArea(centerX, centerY, centerZ, currentTick / SPAWNER_ACTIVATE_AREA_LINE_SLICES, brightness);
        }
    }

    /**
     * �X�|�[���\�ꏊ�}�[�J�[�̕`��.
     */
    private void drawSpawnCheckMarker(SpawnPointMarker marker, Color color, int brightness,
            boolean drawingMarker, boolean drawingGuideline)
    {
        if (marker == null || !(drawingMarker || drawingGuideline))
        {
            return;
        }

        double oMaxX = marker.outerMaxX - renderManager.field_1222_l;
        double oMaxY = marker.outerMaxY - renderManager.field_1221_m;
        double oMaxZ = marker.outerMaxZ - renderManager.field_1220_n;
        double oMinX = marker.outerMinX - renderManager.field_1222_l;
        double oMinY = marker.outerMinY - renderManager.field_1221_m;
        double oMinZ = marker.outerMinZ - renderManager.field_1220_n;
        double iMaxX = marker.innerMaxX - renderManager.field_1222_l;
        double iMaxY = marker.innerMaxY - renderManager.field_1221_m;
        double iMaxZ = marker.innerMaxZ - renderManager.field_1220_n;
        double iMinX = marker.innerMinX - renderManager.field_1222_l;
        double iMinY = marker.innerMinY - renderManager.field_1221_m;
        double iMinZ = marker.innerMinZ - renderManager.field_1220_n;

        if (drawingMarker)
        {
            Tessellator.instance.startDrawingQuads();
            setColorAndBrightness(color, brightness);
            // top
            Tessellator.instance.addVertex(iMinX, oMaxY, iMinZ);
            Tessellator.instance.addVertex(iMinX, oMaxY, iMaxZ);
            Tessellator.instance.addVertex(iMaxX, oMaxY, iMaxZ);
            Tessellator.instance.addVertex(iMaxX, oMaxY, iMinZ);
            // bottom
            Tessellator.instance.addVertex(iMinX, oMinY, iMinZ);
            Tessellator.instance.addVertex(iMaxX, oMinY, iMinZ);
            Tessellator.instance.addVertex(iMaxX, oMinY, iMaxZ);
            Tessellator.instance.addVertex(iMinX, oMinY, iMaxZ);
            // east
            Tessellator.instance.addVertex(iMinX, iMinY, oMinZ);
            Tessellator.instance.addVertex(iMinX, iMaxY, oMinZ);
            Tessellator.instance.addVertex(iMaxX, iMaxY, oMinZ);
            Tessellator.instance.addVertex(iMaxX, iMinY, oMinZ);
            // west
            Tessellator.instance.addVertex(iMinX, iMinY, oMaxZ);
            Tessellator.instance.addVertex(iMaxX, iMinY, oMaxZ);
            Tessellator.instance.addVertex(iMaxX, iMaxY, oMaxZ);
            Tessellator.instance.addVertex(iMinX, iMaxY, oMaxZ);
            // north
            Tessellator.instance.addVertex(oMinX, iMinY, iMinZ);
            Tessellator.instance.addVertex(oMinX, iMinY, iMaxZ);
            Tessellator.instance.addVertex(oMinX, iMaxY, iMaxZ);
            Tessellator.instance.addVertex(oMinX, iMaxY, iMinZ);
            // south
            Tessellator.instance.addVertex(oMaxX, iMinY, iMinZ);
            Tessellator.instance.addVertex(oMaxX, iMaxY, iMinZ);
            Tessellator.instance.addVertex(oMaxX, iMaxY, iMaxZ);
            Tessellator.instance.addVertex(oMaxX, iMinY, iMaxZ);
            Tessellator.instance.draw();
        }

        if (drawingGuideline)
        {
            // �����ɂ��ď�ʃ}�[�J�[�̎l�p�̒��S���W���Z�o
            double x = (marker.innerMaxX + marker.innerMinX) / 2.0D - renderManager.field_1222_l;
            double z = (marker.innerMaxZ + marker.innerMinZ) / 2.0D - renderManager.field_1220_n;
            double bottomY = marker.outerMaxY - renderManager.field_1221_m;
            double topY = Math.min(GUIDELINE_LENGTH + bottomY,
                    (double) WORLD_HEIGHT_MAX - renderManager.field_1221_m);
            Tessellator.instance.startDrawing(GL11.GL_LINES);
            setColorAndBrightness(color, brightness);
            Tessellator.instance.addVertex(x, topY, z);
            Tessellator.instance.addVertex(x, bottomY, z);
            Tessellator.instance.draw();
        }
    }

    /**
     * �X���C���`�����N�g�Ȃǂ̕`��B
     * �n�ʂƕ��s��intervals���̊Ԋu�����������ɏd�˂��ʂɁA�l�p�`��`�悷��J���W.
     */
    private void drawAreaSquares(double minX, double minY, double minZ, double maxX, double maxY, double maxZ,
            double intervals, Color color, int brightness)
    {
        Tessellator.instance.startDrawing(GL11.GL_LINES);
        setColorAndBrightness(color, brightness);

        for (double y = minY; y <= maxY; y += intervals)
        {
            // north
            Tessellator.instance.addVertex(minX, y, minZ);
            Tessellator.instance.addVertex(minX, y, maxZ);
            // west
            Tessellator.instance.addVertex(minX, y, maxZ);
            Tessellator.instance.addVertex(maxX, y, maxZ);
            // south
            Tessellator.instance.addVertex(maxX, y, maxZ);
            Tessellator.instance.addVertex(maxX, y, minZ);
            // east
            Tessellator.instance.addVertex(maxX, y, minZ);
            Tessellator.instance.addVertex(minX, y, minZ);
        }

        Tessellator.instance.draw();
    }

    /**
     * �����̘̂g�̕`��.
     */
    private void drawBoxBorder(double minX, double minY, double minZ, double maxX, double maxY, double maxZ,
            Color color, int brightness)
    {
        Tessellator.instance.startDrawing(GL11.GL_LINES);
        setColorAndBrightness(color, brightness);
        // ���ʂ̎l�p�`
        Tessellator.instance.addVertex(minX, minY, minZ);
        Tessellator.instance.addVertex(minX, minY, maxZ);
        Tessellator.instance.addVertex(minX, minY, maxZ);
        Tessellator.instance.addVertex(maxX, minY, maxZ);
        Tessellator.instance.addVertex(maxX, minY, maxZ);
        Tessellator.instance.addVertex(maxX, minY, minZ);
        Tessellator.instance.addVertex(maxX, minY, minZ);
        Tessellator.instance.addVertex(minX, minY, minZ);
        // ���ʂ̏c�� 4�{
        Tessellator.instance.addVertex(minX, minY, minZ);
        Tessellator.instance.addVertex(minX, maxY, minZ);
        Tessellator.instance.addVertex(minX, minY, maxZ);
        Tessellator.instance.addVertex(minX, maxY, maxZ);
        Tessellator.instance.addVertex(maxX, minY, maxZ);
        Tessellator.instance.addVertex(maxX, maxY, maxZ);
        Tessellator.instance.addVertex(maxX, minY, minZ);
        Tessellator.instance.addVertex(maxX, maxY, minZ);
        // ��ʂ̎l�p�`
        Tessellator.instance.addVertex(minX, maxY, maxZ);
        Tessellator.instance.addVertex(maxX, maxY, maxZ);
        Tessellator.instance.addVertex(maxX, maxY, maxZ);
        Tessellator.instance.addVertex(maxX, maxY, minZ);
        Tessellator.instance.addVertex(maxX, maxY, minZ);
        Tessellator.instance.addVertex(minX, maxY, minZ);
        Tessellator.instance.addVertex(minX, maxY, minZ);
        Tessellator.instance.addVertex(minX, maxY, maxZ);
        Tessellator.instance.draw();
    }

    /**
     * �X�|�[�i�[�̃X�|�[���ە\���p�̃}�[�J�[�`��.
     */
    private void drawSpawnablePointSphere(double x, double y, double z,
            float rotateAngle, Color color, int brightness)
    {
        if (color.getAlpha() <= 0)
        {
            return;
        }

        GL11.glPushMatrix();
        setGLColorAndBrightness(color, brightness);
        GL11.glTranslated(x, y, z);
        // ���_�����
        GL11.glRotatef(90, 1, 0, 0);
        // �����̒l�����ɉ�]������
        GL11.glRotatef(rotateAngle, 0, 0, 1);
        // ���S�̏�������
        sphere.setDrawStyle(GLU.GLU_FILL);
        sphere.draw(SPAWNER_POINT_RADIUS_INNER, SPAWNER_POINT_SLICES_INNER, SPAWNER_POINT_STACKS_INNER);
        // �O���̖�
        sphere.setDrawStyle(GLU.GLU_FILL);
        sphere.draw(SPAWNER_POINT_RADIUS_OUTER, SPAWNER_POINT_SLICES_OUTER, SPAWNER_POINT_STACKS_OUTER);
        // �O���̐�
        sphere.setDrawStyle(GLU.GLU_LINE);
        sphere.draw(SPAWNER_POINT_RADIUS_OUTER, SPAWNER_POINT_SLICES_OUTER, SPAWNER_POINT_STACKS_OUTER);
        GL11.glPopMatrix();
    }

    /**
     * �X�|�[�i�[�������͈͋��̂̕`��.
     */
    private void drawActivateArea(double x, double y, double z, float rotateAngle, int brightness)
    {
        Settings settings = SpawnChecker.getSettings();
        boolean drawingFillSphere = settings.getColorSpawnerActivateArea().getAlpha() > 0;

        if (settings.getColorSpawnerActivateAreaLine().getAlpha() > 0)
        {
            GL11.glPushMatrix();
            setGLColorAndBrightness(settings.getColorSpawnerActivateAreaLine(), brightness);
            GL11.glTranslated(x, y, z);
            // ���̏W�܂镔�������E�Ȃ̂͂Ȃ񂩂��������邩��A90�x��]���㉺�ɏW�܂�悤�ɂ���
            GL11.glRotatef(90, 1, 0, 0);
            // ��
            GL11.glRotatef(rotateAngle, 0, 0, 1);
            sphere.setDrawStyle(GLU.GLU_LINE);
            // ���O�������ĉ��s�����Ⴄ�̂����Ȃ̂Ń��[�J���ϐ��ɕۊǂ��Ă�
            int slices = SPAWNER_ACTIVATE_AREA_LINE_SLICES;
            int stacks = SPAWNER_ACTIVATE_AREA_LINE_STACKS;

            // �ʕ`�悷��ꍇ�͖ʂ̓����ƊO�������ɐ���`��
            if (drawingFillSphere)
            {
                // �h��Ԃ����̂̓����ƊO���ɕ`�悷��
                sphere.draw(SPAWNER_ACTIVATE_AREA_RADIUS + 0.05f, slices, stacks);
                sphere.draw(SPAWNER_ACTIVATE_AREA_RADIUS - 0.05f, slices, stacks);
            }
            else
            {
                sphere.draw(SPAWNER_ACTIVATE_AREA_RADIUS, slices, stacks);
            }

            GL11.glPopMatrix();
        }

        // 2�̐��̊Ԃɖʂ�h��Ԃ�������`��
        if (drawingFillSphere)
        {
            GL11.glPushMatrix();
            GL11.glDisable(GL11.GL_CULL_FACE);
            setGLColor(settings.getColorSpawnerActivateArea());
            GL11.glTranslated(x, y, z);
            sphere.setDrawStyle(GLU.GLU_FILL);
            sphere.draw(SPAWNER_ACTIVATE_AREA_RADIUS, SPAWNER_ACTIVATE_AREA_SLICES, SPAWNER_ACTIVATE_AREA_STACKS);
            GL11.glEnable(GL11.GL_CULL_FACE);
            GL11.glPopMatrix();
        }
    }

    private void setColorAndBrightness(Color color, int brightness)
    {
        Tessellator.instance.setBrightness(brightness);
        Tessellator.instance.setColorRGBA(color.getRed(), color.getGreen(), color.getBlue(), color.getAlpha());
    }

    // �Ă�����[���[�g��Ȃ��ꍇ�̃u���C�g�l�X���f�́A
    // ���C�g�}�b�v�e�N�X�`���ɖ��邳��ݒ肷��̂ł͂Ȃ��A���ڃu���C�g�l�X��F�ɔ��f���Ď������Ă�
    // Tessellator �̂��̂�����̏����悭�������ĂȂ��̂Ŏ��O�ŉ����c
    private void setGLColorAndBrightness(Color color, int brightness)
    {
        int nowBrightness = Math.max(Math.max(color.getRed(), color.getGreen()), color.getBlue());
        float ratio = (float) brightness / (float) nowBrightness;
        int r = (int)(color.getRed() * ratio);
        int g = (int)(color.getGreen() * ratio);
        int b = (int)(color.getBlue() * ratio);
        setGLColor(new Color(r, g, b, color.getAlpha()));
    }

    private void setGLColor(Color c)
    {
        GL11.glColor4ub((byte) c.getRed(), (byte) c.getGreen(), (byte) c.getBlue(), (byte) c.getAlpha());
    }

    @Override
    public void doRender(Entity entity, double x, double y, double z, float yaw, float partialTickTime)
    {
        if (mod_SpawnChecker.DEBUG)
        {
            Profiler.endSection();
            Profiler.endSection();
            Profiler.endSection();
            Profiler.endSection();
            Profiler.endStartSection("spawn checker doRender");
        }

        drawSpawnChecker((EntitySpawnChecker) entity, x, y, z, partialTickTime);

        if (mod_SpawnChecker.DEBUG)
        {
            Profiler.endStartSection("render");
            Profiler.startSection("gameRenderer");
            Profiler.startSection("level");
            Profiler.startSection("entities");
            Profiler.startSection("entities");
        }
    }

    @Override
    public void doRenderShadowAndFire(Entity entity, double x, double y, double z, float yaw, float partialTickTime)
    {
        // nothing
    }
}
